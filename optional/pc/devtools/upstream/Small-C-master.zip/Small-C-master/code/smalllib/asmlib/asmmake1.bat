SET BIN=..\..\bin
SET SRC=..\asmlib

COPY %SRC%\STDIO.H STDIO.H
COPY %SRC%\OBJ1.H OBJ1.H
COPY %SRC%\OBJ2.H OBJ2.H
COPY %SRC%\OBJ3.H OBJ3.H
COPY %SRC%\ASM.H ASM.H
%BIN%\CC %SRC%\ADD32.C >ADD32.ASM -a -p -w
%BIN%\CC %SRC%\ADD64.C >ADD64.ASM -a -p -w
%BIN%\CC %SRC%\AND32.C >AND32.ASM -a -p -w
%BIN%\CC %SRC%\ATOFT.C >ATOFT.ASM -a -p -w
%BIN%\CC %SRC%\ATOLB.C >ATOLB.ASM -a -p -w
%BIN%\CC %SRC%\ATOP.C >ATOP.ASM -a -p -w
%BIN%\CC %SRC%\CMP32.C >CMP32.ASM -a -p -w
%BIN%\CC %SRC%\CMP64.C >CMP64.ASM -a -p -w
%BIN%\CC %SRC%\CPL32.C >CPL32.ASM -a -p -w
%BIN%\CC %SRC%\DIV32.C >DIV32.ASM -a -p -w
%BIN%\CC %SRC%\EQ32.C >EQ32.ASM -a -p -w
%BIN%\CC %SRC%\EXTEND.C >EXTEND.ASM -a -p -w
%BIN%\CC %SRC%\FILE.C >FILE.ASM -a -p -w
%BIN%\CC %SRC%\FT2D.C >FT2D.ASM -a -p -w
%BIN%\CC %SRC%\FT2S.C >FT2S.ASM -a -p -w
%BIN%\CC %SRC%\FTADD.C >FTADD.ASM -a -p -w
%BIN%\CC %SRC%\FTNORMAL.C >FTNORMAL.ASM -a -p -w
%BIN%\CC %SRC%\FTSUB.C >FTSUB.ASM -a -p -w
%BIN%\CC %SRC%\GE32.C >GE32.ASM -a -p -w
%BIN%\CC %SRC%\GT32.C >GT32.ASM -a -p -w
%BIN%\CC %SRC%\INC32.C >INC32.ASM -a -p -w
%BIN%\CC %SRC%\INT.C >INT.ASM -a -p -w
%BIN%\CC %SRC%\ITOFT.C >ITOFT.ASM -a -p -w
%BIN%\CC %SRC%\LE32.C >LE32.ASM -a -p -w
%BIN%\CC %SRC%\LNEG32.C >LNEG32.ASM -a -p -w
%BIN%\CC %SRC%\LSH32.C >LSH32.ASM -a -p -w
%BIN%\CC %SRC%\LSH64.C >LSH64.ASM -a -p -w
%BIN%\CC %SRC%\LT32.C >LT32.ASM -a -p -w
%BIN%\CC %SRC%\LTOX.C >LTOX.ASM -a -p -w
%BIN%\CC %SRC%\MESS.C >MESS.ASM -a -p -w
%BIN%\CC %SRC%\MIT.C >MIT.ASM -a -p -w
%BIN%\CC %SRC%\MOD32.C >MOD32.ASM -a -p -w
%BIN%\CC %SRC%\MOV32.C >MOV32.ASM -a -p -w
%BIN%\CC %SRC%\MOV80.C >MOV80.ASM -a -p -w
%BIN%\CC %SRC%\MUL32.C >MUL32.ASM -a -p -w
%BIN%\CC %SRC%\NE32.C >NE32.ASM -a -p -w
%BIN%\CC %SRC%\NEG32.C >NEG32.ASM -a -p -w
%BIN%\CC %SRC%\OR32.C >OR32.ASM -a -p -w
%BIN%\CC %SRC%\PUTOBJ.C >PUTOBJ.ASM -a -p -w
%BIN%\CC %SRC%\REQ.C >REQ.ASM -a -p -w
%BIN%\CC %SRC%\RSH32.C >RSH32.ASM -a -p -w
%BIN%\CC %SRC%\RSH64.C >RSH64.ASM -a -p -w
%BIN%\CC %SRC%\SCAN.C >SCAN.ASM -a -p -w
%BIN%\CC %SRC%\SUB32.C >SUB32.ASM -a -p -w
%BIN%\CC %SRC%\SUB64.C >SUB64.ASM -a -p -w
%BIN%\CC %SRC%\WAITING.C >WAITING.ASM -a -p -w
%BIN%\CC %SRC%\XOR32.C >XOR32.ASM -a -p -w
